MOBILE INVOICE FILTER
This is a phone-friendly web app. It runs in a browser and processes text-based PDF invoices on the device/browser.

To publish it without a computer:
1. Create a GitHub account (if needed).
2. Create a new repository.
3. Upload index.html from your phone.
4. Enable GitHub Pages for the repository.
5. Open the Pages URL on your phone and optionally add it to the home screen.

The parser is tailored to the two sample invoice formats provided in this conversation.
Scanned/image-only PDFs need OCR support; this version focuses on selectable-text PDFs.
